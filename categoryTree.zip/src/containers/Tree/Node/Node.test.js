import React from 'react';
import Node from './Node';

import {configure, shallow} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

configure({adapter: new Adapter()});
let wrapper;
beforeEach(() => wrapper = shallow(<Node />))
describe('<Node/>', () => {

    it('should render itself: 0 Node (don\'t have children and collapse)', () => {
        wrapper.setState({collapse: true});
        wrapper.setProps({
            name: 'a',
            id: 'tree/0',
            children: []
        });
        expect(wrapper.find(Node)).toHaveLength(0);
    })

    it('should render itself: 0 Node (have children but collapse)', () => {
        const n = 10000;
        let i = 0;
        let children = [];
        while (i < n) {
            children.push({
                id: 'tree/0/' + i,
                name: i,
                children: [],
                counter: 0
            })
            i++;
        }
        wrapper.setState({collapse: true});
        wrapper.setProps({
            name: 'a',
            id: 'tree/0',
            children: children
        });
        expect(wrapper.find(Node)).toHaveLength(0);
    })

    it('should render tree with n nodes', () => {
        const n = 10000;
        let i = 0;
        let children = [];
        while (i < n) {
            children.push({
                id: 'tree/0/' + i,
                name: i,
                children: [],
                counter: 0
            })
            i++;
        }
        wrapper.setState({collapse: false});
        wrapper.setProps({
            name: 'a',
            id: 'tree/0',
            children: children
        });
        expect(wrapper.find(Node)).toHaveLength(n);
    })


    it('should render itself node (dont collapse but don\'t have children)', () => {
        wrapper.setState({collapse: false});
        wrapper.setProps({
            name: 'a',
            id: 'tree/0',
            children: []
        });
        expect(wrapper.find(Node)).toHaveLength(0);
    })
}
);